// globals.js
const selectedValues = {
    selectedBorough: 'None selected',
    xAxisAttribute: 'None selected',
    yAxisAttribute: 'None selected'
};